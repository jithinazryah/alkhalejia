<htlml>
    <head>
        <style>
            .left-half{
                width: 50%;
                float: left;
            }
            .right-half{
                width: 50%;
                float: left;
            }
        </style>
    </head>
    <body>
        <div class="header">
            <div class="container">
                <div class="row">
                    <table>
                        <tr>
                            <td style="width: 50%; float: left;"><img src="" alt="image"/></td>
                            <td>ALKHALEJIA AGGREGATES FZE
                                Phone No: 07-204-1315

                                Email: alkhalejia@rakfzbc.ae

                                VAT ID : 100234434700003</td>
                        </tr>
                    </table>
                    <table>
                        <tr>
                            <td style="width: 50%; float: left;">ALKHALEJIA AGGREGATES FZE
                                Phone No: 07-204-1315

                                Email: alkhalejia@rakfzbc.ae

                                VAT ID : 100234434700003</td>
                            <td style="width: 50%; float: left;">ALKHALEJIA AGGREGATES FZE
                                Phone No: 07-204-1315

                                Email: alkhalejia@rakfzbc.ae

                                VAT ID : 100234434700003</td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>
    </body>
</htlml>